module spram #(
		parameter         ADDR_WIDTH  = 16        ,
		parameter         DATA_WIDTH  = 32        ,
		parameter         STYLE       = "block"
		
    )
    (      
		input  logic                      	cl	,
		input  logic                      	cs	,
		input  logic                      	we	,
		input  logic  	[ADDR_WIDTH-1 : 0]  	a	,
		input  logic  	[DATA_WIDTH-1 : 0]  	d	,
		output logic 	[DATA_WIDTH-1 : 0]  	q
    );

localparam ADDR_SIZE = 2**ADDR_WIDTH;
(* ram_style = STYLE *)logic [DATA_WIDTH-1:0] RAM[0 : ADDR_SIZE-1];

integer i;
initial begin 
	for (i = 0; i< ADDR_SIZE; i= i+1) RAM[i] = 0;

end
always @(posedge cl)
	begin
		if (cs)
			begin
				if (we)
					RAM[a] <= d;
				else
					q <= RAM[a];
			end
	end

endmodule


module sprom# (
		parameter         MEMORY_SIZE  	= 1048576 ,
                parameter         ADDR_WIDTH	= 14	 

	)
	(      
		input  logic     		clk,
		input  logic     		cs,
		input  logic [ADDR_WIDTH-1:0] 	a,
		output logic [63:0]		q
    	);

xpm_memory_sprom #(
  .ADDR_WIDTH_A      (ADDR_WIDTH),
  .READ_DATA_WIDTH_A (64	),
  .MEMORY_SIZE       (MEMORY_SIZE),
  .MEMORY_PRIMITIVE  ("block"	),
  .MEMORY_OPTIMIZATION("false"	),
  .READ_LATENCY_A    (1		),
  .MEMORY_INIT_FILE  ("none"	),
  .USE_MEM_INIT      (0		)
) sprom_16384x64bit (
  .clka   (clk		),
  .ena    (cs		),
  .addra  (a		),
  .douta  (q		),

  .regcea (1'b1		),
  .rsta   (1'b0		),
  .sleep  (1'b0		),

  .injectsbiterra(1'b0	),
  .injectdbiterra(1'b0	),
  .sbiterra(		),
  .dbiterra(		)
);

endmodule

###############USB Clock#####################################################
create_clock -name usb_clk -period 16.667 [get_ports cptra_ss_usb_ulpi_clk_i]
#############################################################################

#################Jlink JATAG Clock###########################################
create_clock -name jtag_clk -period 100.0 [get_ports jlink_tck]
#############################################################################

##############USB ULPI IO Timing#############################################
# PHY -> FPGA
set_input_delay  -clock usb_clk -max 3.65 \
   [get_ports {cptra_ss_usb_ulpi_data_io[*] cptra_ss_usb_ulpi_dir_i cptra_ss_usb_ulpi_nxt_i}]
set_input_delay  -clock usb_clk -min 1.0 \
   [get_ports {cptra_ss_usb_ulpi_data_io[*] cptra_ss_usb_ulpi_dir_i cptra_ss_usb_ulpi_nxt_i}]
# FPGA -> PHY
set_output_delay -clock usb_clk -max 5.15 \
   [get_ports {cptra_ss_usb_ulpi_data_io[*] cptra_ss_usb_ulpi_stp_o}]
set_output_delay -clock usb_clk -min 0.0 \
   [get_ports {cptra_ss_usb_ulpi_data_io[*] cptra_ss_usb_ulpi_stp_o}]
#############################################################################

######################Async groups###########################################
set_clock_groups -asynchronous \
    -group {clk_out1_caliptra_ss_bd_caliptra_ss_mmcm_0} \
    -group {clk_out2_caliptra_ss_bd_caliptra_ss_mmcm_0} \
    -group {usb_clk} \
    -group {jtag_clk}
#############################################################################

###################Exceptions################################################
set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets jlink_tck_IBUF_inst/O]
set_property SEVERITY Warning [get_drc_checks LUTLP-1]
#############################################################################

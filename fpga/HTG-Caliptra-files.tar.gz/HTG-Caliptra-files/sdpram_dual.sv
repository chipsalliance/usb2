module sdpram_dual #(
		parameter         ADDR_WIDTH  = 10        ,
		parameter         DATA_WIDTH  = 32        ,
		parameter         STYLE       = "block"
		
    )
    (      
		input  logic                      	clka	,
		input  logic                      	clkb	,
		input  logic                      	cena	,
		input  logic                      	cenb	,
		input  logic                      	wea	,
		input  logic  	[ADDR_WIDTH-1 : 0]  	aa	,
		input  logic  	[ADDR_WIDTH-1 : 0]  	ab	,
		input  logic  	[DATA_WIDTH-1 : 0]  	d	,
		output logic 	[DATA_WIDTH-1 : 0]  	q
    );

localparam ADDR_SIZE = 2**ADDR_WIDTH;
(* ram_style = STYLE *)logic [DATA_WIDTH-1:0] RAM[0: ADDR_SIZE-1];

integer i;
initial begin 
	for (i = 0; i< ADDR_SIZE; i= i+1) RAM[i] = 0;

end

always @(posedge clka) 
begin 
  if (cena)
    begin
      if (wea)
        RAM[aa] <= d;
    end
end

always @(posedge clkb) 
begin
  if (cenb)
    begin
      q <= RAM[ab];
    end
end

endmodule


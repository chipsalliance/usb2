############################Clock and Reset#######################################  
set_property PACKAGE_PIN AW28 [ get_ports ref_clock_156p25mhz_clk_p ]
set_property IOSTANDARD LVDS [get_ports ref_clock_156p25mhz_clk_p]
#set_property IOSTANDARD DIFF_HSTL_I_12 [ get_ports ref_clock_200mhz_clk_p ]

set_property PACKAGE_PIN AY28 [ get_ports ref_clock_156p25mhz_clk_n ]
set_property IOSTANDARD LVDS [get_ports ref_clock_156p25mhz_clk_n]
#set_property IOSTANDARD DIFF_HSTL_I_12 [ get_ports ref_clock_200mhz_clk_n ]

#Push button
set_property PACKAGE_PIN AJ34 [ get_ports resetn_i ]
set_property IOSTANDARD LVCMOS12 [ get_ports resetn_i ]

set_property PACKAGE_PIN AK32 [ get_ports usb_phy_resetn_i ]
set_property IOSTANDARD LVCMOS12 [ get_ports usb_phy_resetn_i ]

set_property PACKAGE_PIN BB22 [ get_ports usb_phy_resetn_o ]
set_property IOSTANDARD LVCMOS18 [ get_ports usb_phy_resetn_o ]
###################################################################################

#################Debug LEDs########################################################
set_property LOC AP28  [get_ports GPIO_o[0]]
set_property IOSTANDARD LVCMOS18 [get_ports GPIO_o[0]]

set_property LOC AN28  [get_ports GPIO_o[1]]
set_property IOSTANDARD LVCMOS18 [get_ports GPIO_o[1]]

set_property LOC AP26  [get_ports GPIO_o[2]]
set_property IOSTANDARD LVCMOS18 [get_ports GPIO_o[2]]
###################################################################################


#####################ULPI interface################################################
set_property LOC AW16  [get_ports cptra_ss_usb_ulpi_clk_i]
set_property IOSTANDARD LVCMOS18 [get_ports cptra_ss_usb_ulpi_clk_i]

set_property LOC AL15  [get_ports cptra_ss_usb_ulpi_data_io[0]]
set_property IOSTANDARD LVCMOS18 [get_ports cptra_ss_usb_ulpi_data_io[0]]

set_property LOC AM15  [get_ports cptra_ss_usb_ulpi_data_io[1]]
set_property IOSTANDARD LVCMOS18 [get_ports cptra_ss_usb_ulpi_data_io[1]]

set_property LOC AP15 [get_ports cptra_ss_usb_ulpi_data_io[2]]
set_property IOSTANDARD LVCMOS18 [get_ports cptra_ss_usb_ulpi_data_io[2]]

set_property LOC AM14  [get_ports cptra_ss_usb_ulpi_data_io[3]]
set_property IOSTANDARD LVCMOS18 [get_ports cptra_ss_usb_ulpi_data_io[3]]

set_property LOC AN14  [get_ports cptra_ss_usb_ulpi_data_io[4]]
set_property IOSTANDARD LVCMOS18 [get_ports cptra_ss_usb_ulpi_data_io[4]]

set_property LOC AN13  [get_ports cptra_ss_usb_ulpi_data_io[5]]
set_property IOSTANDARD LVCMOS18 [get_ports cptra_ss_usb_ulpi_data_io[5]]

set_property LOC AT15  [get_ports cptra_ss_usb_ulpi_data_io[6]]
set_property IOSTANDARD LVCMOS18 [get_ports cptra_ss_usb_ulpi_data_io[6]]

set_property LOC AU15  [get_ports cptra_ss_usb_ulpi_data_io[7]]
set_property IOSTANDARD LVCMOS18 [get_ports cptra_ss_usb_ulpi_data_io[7]]

set_property LOC AW15  [get_ports cptra_ss_usb_ulpi_dir_i]
set_property IOSTANDARD LVCMOS18 [get_ports cptra_ss_usb_ulpi_dir_i]

set_property LOC AL14  [get_ports cptra_ss_usb_ulpi_stp_o]
set_property IOSTANDARD LVCMOS18 [get_ports cptra_ss_usb_ulpi_stp_o]

set_property LOC AP14  [get_ports cptra_ss_usb_ulpi_nxt_i]
set_property IOSTANDARD LVCMOS18 [get_ports cptra_ss_usb_ulpi_nxt_i]
###################################################################################


#####################I3C interface#################################################
set_property LOC AN22  [get_ports cptra_ss_i3c_scl_io]
set_property IOSTANDARD LVCMOS18 [get_ports cptra_ss_i3c_scl_io]

set_property LOC AN21  [get_ports cptra_ss_i3c_sda_io]
set_property IOSTANDARD LVCMOS18 [get_ports cptra_ss_i3c_sda_io]
###################################################################################



#####################Jlink interface###############################################
set_property LOC BD23  [get_ports jlink_tck]
set_property IOSTANDARD LVCMOS18 [get_ports jlink_tck]

set_property LOC BE23  [get_ports jlink_tms]
set_property IOSTANDARD LVCMOS18 [get_ports jlink_tms]

set_property LOC BD21  [get_ports jlink_tdi]
set_property IOSTANDARD LVCMOS18 [get_ports jlink_tdi]

set_property LOC BE21  [get_ports jlink_tdo]
set_property IOSTANDARD LVCMOS18 [get_ports jlink_tdo]

set_property LOC BE22 [get_ports jlink_trstn]
set_property IOSTANDARD LVCMOS18 [get_ports jlink_trstn]

set_property LOC BF33  [get_ports jlink_mux_sel[0]]
set_property IOSTANDARD LVCMOS12 [get_ports jlink_mux_sel[0]]

set_property LOC AK27  [get_ports jlink_mux_sel[1]]
set_property IOSTANDARD LVCMOS12 [get_ports jlink_mux_sel[1]]
###################################################################################


###################MMCM location constraints#######################################  
set_property LOC MMCM_X0Y5 [get_cells caliptra_ss_bd_inst/caliptra_ss_mmcm/inst/mmcme4_adv_inst]
set_property CLOCK_REGION X4Y5 [get_cells caliptra_ss_bd_inst/caliptra_ss_mmcm/inst/clkin1_bufg1]
###################################################################################


###################################################################################
set_property CLOCK_DEDICATED_ROUTE FALSE [get_nets resetn_i_IBUF_inst/O]
###################################################################################


###################USB Core area constraints#######################################   
startgroup
create_pblock pblock_usb_core_i
resize_pblock pblock_usb_core_i -add {SLICE_X77Y390:SLICE_X148Y479 SLICE_X77Y480:SLICE_X148Y569 DSP48E2_X10Y156:DSP48E2_X19Y191 DSP48E2_X10Y192:DSP48E2_X19Y227 IOB_X0Y338:IOB_X0Y415 IOB_X0Y416:IOB_X0Y493 LAGUNA_X10Y360:LAGUNA_X19Y479 LAGUNA_X10Y480:LAGUNA_X19Y599 RAMB18_X5Y156:RAMB18_X10Y191 RAMB18_X5Y192:RAMB18_X10Y227 RAMB36_X5Y78:RAMB36_X10Y95 RAMB36_X5Y96:RAMB36_X10Y113 URAM288_X1Y104:URAM288_X2Y127 URAM288_X1Y128:URAM288_X2Y151}
add_cells_to_pblock pblock_usb_core_i [get_cells [list caliptra_ss_wrapper_i/caliptra_ss_top_inst/usb_core_i]]
endgroup
################################################################################### 


